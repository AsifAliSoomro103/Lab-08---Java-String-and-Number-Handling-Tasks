import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RandomPrimeGenerator5 {

    public static int generateRandomPrime(int min, int max) {
        if (min > max) {
            throw new IllegalArgumentException("min must be less than or equal to max");
        }

        List<Integer> primes = new ArrayList<>();
        for (int num = min; num <= max; num++) {
            if (isPrime(num)) {
                primes.add(num);
            }
        }

        if (primes.isEmpty()) {
            throw new IllegalArgumentException("No primes found in the given range [" + min + ", " + max + "]");
        }

        Random random = new Random();
        int index = random.nextInt(primes.size());
        return primes.get(index);
    }

    private static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        if (n <= 3) {
            return true;
        }
        if (n % 2 == 0 || n % 3 == 0) {
            return false;
        }
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        int min = 10;
        int max = 20;
        System.out.println("A random prime between " + min + " and " + max + ": " + generateRandomPrime(min, max));
    }
}