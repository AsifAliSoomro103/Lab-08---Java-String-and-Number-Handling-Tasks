import java.util.HashSet;

public class LongestSubstring3 {
    public static int longestUniqueSubstring(String str) {
        int maxLength = 0;
        int start = 0;
        HashSet<Character> seenChars = new HashSet<>();

        for (int end = 0; end < str.length(); end++) {
            char currentChar = str.charAt(end);

            while (seenChars.contains(currentChar)) {
                seenChars.remove(str.charAt(start));
                start++;
            }

            seenChars.add(currentChar);
            maxLength = Math.max(maxLength, end - start + 1);
        }

        return maxLength;
    }

    public static void main(String[] args) {
        String input = "abcabcbb";
        int result = longestUniqueSubstring(input);
        System.out.println("Length of longest substring without repeating characters: " + result);
    }
}
